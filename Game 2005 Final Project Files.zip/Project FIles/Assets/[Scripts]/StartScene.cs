using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class StartScene : MonoBehaviour
{
   public void ChangeScene()
    {
        SceneManager.LoadSceneAsync("Main", LoadSceneMode.Single);
    }
}
