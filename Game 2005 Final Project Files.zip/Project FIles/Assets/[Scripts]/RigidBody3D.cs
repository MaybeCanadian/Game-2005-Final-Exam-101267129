﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BodyType
{
    STATIC,
    DYNAMIC
}


[System.Serializable]
public class RigidBody3D : MonoBehaviour
{
    [Header("Gravity Simulation")]
    public float gravityScale;
    public float mass;
    public BodyType bodyType;
    public float timer;
    public bool isFalling;

    [Header("Attributes")]
    public Vector3 velocity;
    public Vector3 acceleration;
    private float gravity;

    private bool Activated = false;
    private CollisionManager CollisionManagerScript;

    // Start is called before the first frame update
    void Start()
    {
        CollisionManagerScript = FindObjectOfType<CollisionManager>(); 
        timer = 0.0f;
        gravity = -0.001f;
        velocity = Vector3.zero;
        acceleration = new Vector3(0.0f, gravity * gravityScale, 0.0f);

        isFalling = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(Activated == false)
        {
            if(CollisionManagerScript.Activated == true)
            {
                Activated = true;
                if(bodyType == BodyType.DYNAMIC)
                {
                    isFalling = true;
                }
            }
        }

        if (bodyType == BodyType.DYNAMIC)
        {
            if (isFalling)
            {
                timer += Time.deltaTime;
                
                if (gravityScale < 0)
                {
                    gravityScale = 0;
                }

                if (gravityScale > 0)
                {
                    velocity += acceleration * 0.5f * timer * timer;
                    transform.position += velocity;
                }
            }
        }
    }

    public void Stop()
    {
        timer = 0;
        isFalling = false;
    }

}
